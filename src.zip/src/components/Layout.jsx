import { useState, useEffect, useRef } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { 
  Home, Layers, Calendar, FileText, Settings, 
  Search, Bell, Sun, Moon, CheckCircle, BookOpen 
} 
from 'lucide-react';


export default function Layout() {
  const role = localStorage.getItem('userRole');
  const name = localStorage.getItem('userName');
  const [isDarkMode, setIsDarkMode] = useState(false);
  
  // 1. New States for the Global Search Dropdown
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchActive, setIsSearchActive] = useState(false);
  
  const navigate = useNavigate();
  const handleLogout = () => {
    localStorage.removeItem('userRole');
    localStorage.removeItem('userName');
    navigate('/login');
  };
  const searchInputRef = useRef(null);

  // 2. Define all the searchable pages in your app
  const menuItems =
  role === "admin"
    ? [
        { name: "Dashboard", path: "/dashboard", icon: <Home size={16} /> },
        { name: "Projects", path: "/dashboard/projects", icon: <Layers size={16} /> },
        { name: "Tasks", path: "/dashboard/tasks", icon: <CheckCircle size={16} /> },
        { name: "Learning Log", path: "/dashboard/learning-log", icon: <BookOpen size={16} /> },
        { name: "Calendar", path: "/dashboard/calendar", icon: <Calendar size={16} /> },
        { name: "Reports", path: "/dashboard/reports", icon: <FileText size={16} /> },
        { name: "Settings", path: "/dashboard/settings", icon: <Settings size={16} /> },
      ]
    : [
        { name: "Dashboard", path: "/intern-dashboard", icon: <Home size={16} /> },
        { name: "My Tasks", path: "/intern-dashboard/my-tasks", icon: <CheckCircle size={16} /> },
        { name: "Learning Log", path: "/intern-dashboard/learning-log", icon: <BookOpen size={16} /> },
        { name: "Calendar", path: "/intern-dashboard/calendar", icon: <Calendar size={16} /> },
        { name: "Chat", path: "/intern-dashboard/chat", icon: <FileText size={16} /> },
        { name: "Profile", path: "/intern-dashboard/profile", icon: <Settings size={16} /> },
      ];
 

  // 3. Filter the menu based on what the user types
  const filteredPages = menuItems.filter(item => 
    item.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Dark Mode Logic
  useEffect(() => {
    if (isDarkMode) document.body.classList.add('dark-mode');
    else document.body.classList.remove('dark-mode');
  }, [isDarkMode]);

  // Keyboard Shortcut Logic (Cmd+K or Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault(); 
        searchInputRef.current?.focus(); 
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, []);

  // 4. Action when user clicks a Page in the dropdown
  const handlePageClick = (path) => {
    navigate(path);
    setSearchQuery('');
    setIsSearchActive(false);
    searchInputRef.current?.blur();
  };

  // 5. Action when user clicks "Search Tasks" in the dropdown
  const handleTaskSearchClick = () => {
    navigate( role=== "admin" ? `/dashboard/tasks?q=${searchQuery}` : `/intern-dashboard/MyTasks?q=${searchQuery}`); 
    setSearchQuery('');
    setIsSearchActive(false);
    searchInputRef.current?.blur();
  };

  return (
    <div className="dashboard-layout">
      {/* SIDEBAR */}
      <aside className="sidebar">
        <div className="logo-container">
          <h2>InternTrack</h2>
        </div>
        <nav className="nav-menu">
  {menuItems.map((item) => (
    <NavLink
      key={item.name}
      to={item.path}
      end={item.name === "Dashboard"}
      className={({ isActive }) =>
        isActive ? "nav-item active" : "nav-item"
    }
    >
      {item.icon}
      <span>{item.name}</span>
    </NavLink>
  ))}
</nav>
        

<button onClick={handleLogout} 
className="logout-btn">
  🚪 Logout
</button>
       
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="main-content">
        {/* TOP HEADER */}
        <header className="top-header">
          
          {/* SEARCH BAR CONTAINER */}
          <div className="search-bar" style={{ position: 'relative' }}>
            <Search size={18} color="#9ca3af" />
            <input 
              ref={searchInputRef}
              type="text" 
              placeholder="Search pages or tasks..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchActive(true)}
              // The timeout ensures clicks on the dropdown register before the menu hides
              onBlur={() => setTimeout(() => setIsSearchActive(false), 200)}
            />
            <span className="shortcut-key">⌘K</span>

            {/* NEW: THE DROPDOWN MENU */}
            {isSearchActive && searchQuery && (
              <div style={{
                position: 'absolute',
                top: '110%',
                left: 0,
                width: '100%',
                background: isDarkMode ? '#1f2937' : '#fff',
                border: `1px solid ${isDarkMode ? '#374151' : '#e5e7eb'}`,
                borderRadius: '12px',
                boxShadow: '0 10px 25px rgba(0,0,0,0.1)',
                zIndex: 50,
                overflow: 'hidden'
              }}>
                
                {/* Section 1: Matching Pages */}
                {filteredPages.length > 0 && (
                  <div style={{ padding: '8px' }}>
                    <div style={{ fontSize: '11px', fontWeight: 'bold', color: '#9ca3af', padding: '4px 8px', textTransform: 'uppercase' }}>
                      Navigate to Menu
                    </div>
                    {filteredPages.map(page => (
                      <div 
                        key={page.path}
                        onClick={() => handlePageClick(page.path)}
                        style={{
                          display: 'flex', alignItems: 'center', gap: '10px', padding: '10px',
                          cursor: 'pointer', borderRadius: '8px', color: isDarkMode ? '#f9fafb' : '#1f2937'
                        }}
                        onMouseEnter={(e) => e.currentTarget.style.backgroundColor = isDarkMode ? '#374151' : '#f3f4f6'}
                        onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                      >
                        {page.icon} {page.name}
                      </div>
                    ))}
                  </div>
                )}
                
                {/* Section 2: Search the Tasks Database */}
                <div style={{ borderTop: `1px solid ${isDarkMode ? '#374151' : '#f3f4f6'}`, padding: '8px' }}>
                   <div 
                      onClick={handleTaskSearchClick}
                      style={{
                        display: 'flex', alignItems: 'center', gap: '10px', padding: '10px',
                        cursor: 'pointer', borderRadius: '8px', color: '#10b981', fontWeight: '500'
                      }}
                      onMouseEnter={(e) => e.currentTarget.style.backgroundColor = isDarkMode ? '#374151' : '#dcfce7'}
                      onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'transparent'}
                    >
                      <Search size={16} /> Search tasks for "{searchQuery}"
                    </div>
                </div>

              </div>
            )}
          </div>
          {/* END SEARCH BAR CONTAINER */}

          <div className="header-actions">
            <button className="icon-btn" onClick={() => setIsDarkMode(!isDarkMode)}>
              {isDarkMode ? <Moon size={20} color="#fcd34d" /> : <Sun size={20} />}
            </button>
            <button className="icon-btn notification">
              <Bell size={20} />
              <span className="badge">3</span>
            </button>
            <div className="user-profile">
              <div className="avatar">{name ? name.charAt(0).toUpperCase() : 'U'}</div>
              <div className="user-info">
                <span className="user-name">{name}</span>
                <span className="user-role">{role==="admin" ? "super admin" : "Intern"}</span>
              </div>
            </div>
          </div>
        </header>

        <Outlet />
      </main>
    </div>
  );
}