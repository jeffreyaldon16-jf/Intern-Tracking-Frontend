import { useState } from "react";

export default function Calendar() {
  const [events] = useState([
    {
      id: 1,
      title: "React Assignment Submission",
      date: "10-07-2026",
      type: "Deadline",
    },
    {
      id: 2,
      title: "Weekly Team Meeting",
      date: "12-07-2026",
      type: "Meeting",
    },
    {
      id: 3,
      title: "Flask Training Session",
      date: "15-07-2026",
      type: "Training",
    },
  ]);

  return (
    <div style={{ padding: "30px" }}>
      <h1>📅 Calendar</h1>

      <div
        style={{
          marginTop: "20px",
          display: "flex",
          flexDirection: "column",
          gap: "15px",
        }}
      >
        {events.map((event) => (
          <div
            key={event.id}
            style={{
              background: "#fff",
              padding: "20px",
              borderRadius: "10px",
              boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
              borderLeft: "5px solid #2563eb",
            }}
          >
            <h3>{event.title}</h3>

            <p>
              📅 <strong>Date:</strong> {event.date}
            </p>

            <p>
              📌 <strong>Type:</strong> {event.type}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}