import { useState } from "react";

export default function Profile() {
  const [profile] = useState({
    name: localStorage.getItem("userName") || "Intern",
    role: "Intern",
    email: "intern@example.com",
    department: "Software Development",
    joiningDate: "01-07-2026",
    mentor: "Super Admin",
  });

  return (
    <div style={{ padding: "30px" }}>
      <h1>👤 My Profile</h1>

      <div
        style={{
          marginTop: "25px",
          background: "#fff",
          borderRadius: "12px",
          padding: "30px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
          maxWidth: "700px",
        }}
      >
        <div style={{ textAlign: "center", marginBottom: "25px" }}>
          <img
            src="https://ui-avatars.com/api/?name=Intern&background=2563eb&color=fff&size=120"
            alt="Profile"
            style={{
              width: "120px",
              height: "120px",
              borderRadius: "50%",
            }}
          />

          <h2 style={{ marginTop: "15px" }}>{profile.name}</h2>
          <p style={{ color: "#666" }}>{profile.role}</p>
        </div>

        <table style={{ width: "100%" }}>
          <tbody>
            <tr>
              <td><strong>Email</strong></td>
              <td>{profile.email}</td>
            </tr>

            <tr>
              <td><strong>Department</strong></td>
              <td>{profile.department}</td>
            </tr>

            <tr>
              <td><strong>Joining Date</strong></td>
              <td>{profile.joiningDate}</td>
            </tr>

            <tr>
              <td><strong>Mentor</strong></td>
              <td>{profile.mentor}</td>
            </tr>
          </tbody>
        </table>

        <button
          style={{
            marginTop: "25px",
            padding: "12px 20px",
            background: "#2563eb",
            color: "#fff",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          Edit Profile
        </button>
      </div>
    </div>
  );
}