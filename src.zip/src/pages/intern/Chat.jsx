import { useState } from "react";

export default function Chat() {
  const [messages, setMessages] = useState([
    {
      id: 1,
      sender: "Admin",
      text: "Welcome to InternTrack 👋",
      time: "09:00 AM",
    },
    {
      id: 2,
      sender: "You",
      text: "Thank you! Happy to join the internship.",
      time: "09:02 AM",
    },
  ]);

  const [newMessage, setNewMessage] = useState("");

  const sendMessage = () => {
    if (!newMessage.trim()) return;

    setMessages([
      ...messages,
      {
        id: Date.now(),
        sender: "You",
        text: newMessage,
        time: new Date().toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        }),
      },
    ]);

    setNewMessage("");
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1>💬 Chat with Admin</h1>

      <div
        style={{
          marginTop: "20px",
          border: "1px solid #ddd",
          borderRadius: "10px",
          height: "450px",
          overflowY: "auto",
          padding: "20px",
          background: "#fafafa",
        }}
      >
        {messages.map((msg) => (
          <div
            key={msg.id}
            style={{
              textAlign: msg.sender === "You" ? "right" : "left",
              marginBottom: "15px",
            }}
          >
            <div
              style={{
                display: "inline-block",
                background:
                  msg.sender === "You" ? "#2563eb" : "#e5e7eb",
                color: msg.sender === "You" ? "white" : "black",
                padding: "10px 15px",
                borderRadius: "12px",
                maxWidth: "70%",
              }}
            >
              <strong>{msg.sender}</strong>
              <br />
              {msg.text}
              <br />
              <small>{msg.time}</small>
            </div>
          </div>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          gap: "10px",
          marginTop: "20px",
        }}
      >
        <input
          type="text"
          placeholder="Type your message..."
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          style={{
            flex: 1,
            padding: "12px",
            borderRadius: "8px",
            border: "1px solid #ccc",
          }}
        />

        <button
          onClick={sendMessage}
          style={{
            padding: "12px 25px",
            background: "#2563eb",
            color: "white",
            border: "none",
            borderRadius: "8px",
            cursor: "pointer",
          }}
        >
          Send
        </button>
      </div>
    </div>
  );
}