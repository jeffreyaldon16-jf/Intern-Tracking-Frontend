export default function Dashboard() {
  const user = localStorage.getItem("userName") || "Intern";

  return (
    <div>
      <h1>Welcome, {user} 👋</h1>
      <p>Here's your internship overview.</p>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "20px",
          marginTop: "30px",
        }}
      >
        <div style={cardStyle}>
          <h3>📋 My Tasks</h3>
          <h1>5</h1>
        </div>

        <div style={cardStyle}>
          <h3>📘 Learning Log</h3>
          <h1>12</h1>
        </div>

        <div style={cardStyle}>
          <h3>💬 Messages</h3>
          <h1>3</h1>
        </div>
      </div>

      <div
        style={{
          marginTop: "30px",
          background: "white",
          padding: "20px",
          borderRadius: "10px",
        }}
      >
        <h2>Today's Progress</h2>

        <ul>
          <li>✅ Complete assigned tasks</li>
          <li>📖 Update learning log</li>
          <li>💬 Reply to admin messages</li>
          <li>📅 Check calendar events</li>
        </ul>
      </div>
    </div>
  );
}

const cardStyle = {
  background: "white",
  padding: "20px",
  borderRadius: "10px",
  textAlign: "center",
  boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
};