import { useState } from "react";

export default function LearningLog() {
  const [logs] = useState([
    {
      date: "08-07-2026",
      topic: "React Components",
      hours: 2,
      status: "Completed",
    },
    {
      date: "09-07-2026",
      topic: "Flask REST API",
      hours: 3,
      status: "In Progress",
    },
  ]);

  return (
    <div style={{ padding: "30px" }}>
      <h1>📘 Learning Log</h1>

      <table
        style={{
          width: "100%",
          marginTop: "20px",
          borderCollapse: "collapse",
        }}
      >
        <thead>
          <tr style={{ background: "#2563eb", color: "white" }}>
            <th style={th}>Date</th>
            <th style={th}>Topic</th>
            <th style={th}>Hours</th>
            <th style={th}>Status</th>
          </tr>
        </thead>

        <tbody>
          {logs.map((log, index) => (
            <tr key={index}>
              <td style={td}>{log.date}</td>
              <td style={td}>{log.topic}</td>
              <td style={td}>{log.hours}</td>
              <td style={td}>{log.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const th = {
  padding: "12px",
};

const td = {
  padding: "12px",
  borderBottom: "1px solid #ddd",
};