import { useState } from "react";

export default function MyTasks() {
  const [tasks] = useState([
    {
      id: 1,
      title: "Complete React Login UI",
      priority: "High",
      status: "Pending",
      dueDate: "2026-07-10",
    },
    {
      id: 2,
      title: "Learn Flask APIs",
      priority: "Medium",
      status: "In Progress",
      dueDate: "2026-07-12",
    },
    {
      id: 3,
      title: "Submit Daily Report",
      priority: "Low",
      status: "Completed",
      dueDate: "2026-07-08",
    },
  ]);

  return (
    <div style={{ padding: "30px" }}>
      <h1>📋 My Tasks</h1>

      <table
        style={{
          width: "100%",
          marginTop: "20px",
          borderCollapse: "collapse",
        }}
      >
        <thead>
          <tr style={{ background: "#2563eb", color: "white" }}>
            <th style={th}>Task</th>
            <th style={th}>Priority</th>
            <th style={th}>Status</th>
            <th style={th}>Due Date</th>
          </tr>
        </thead>

        <tbody>
          {tasks.map((task) => (
            <tr key={task.id}>
              <td style={td}>{task.title}</td>
              <td style={td}>{task.priority}</td>
              <td style={td}>{task.status}</td>
              <td style={td}>{task.dueDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const th = {
  padding: "12px",
};

const td = {
  padding: "12px",
  borderBottom: "1px solid #ddd",
};