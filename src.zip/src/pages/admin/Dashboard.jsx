import { useState, useEffect } from 'react';
import { Calendar, Layers, CheckCircle, Clock, Crown, Trash2, MessageSquare, Send, User, Ghost, PieChart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Chart } from "react-google-charts";

export default function Dashboard() {
  const [tasks, setTasks] = useState([]);
  const [projects, setProjects] = useState([]);
  
  // Q&A Board State
  const [questions, setQuestions] = useState([
    { id: 1, author: 'Anonymous', text: 'Does anyone know how to fix the CORS error when connecting the Flask API?', replies: 3, time: '1h ago' },
    { id: 2, author: 'Sarah M.', text: 'Where can I find the official hex codes for the company branding?', replies: 1, time: '3h ago' }
  ]);
  const [newQuestion, setNewQuestion] = useState('');
  const [isAnonymous, setIsAnonymous] = useState(false);

  const navigate = useNavigate();
  const TASKS_API_URL = 'http://127.0.0.1:5000/api/tasks';
  const PROJECTS_API_URL = 'http://127.0.0.1:5000/api/projects';

  useEffect(() => { 
    fetchTasks(); 
    fetchProjects();
  }, []);

  const fetchTasks = async () => {
    try {
      const response = await fetch(TASKS_API_URL);
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error("Error fetching tasks:", error);
    }
  };

  const fetchProjects = async () => {
    try {
      const response = await fetch(PROJECTS_API_URL);
      const data = await response.json();
      setProjects(data);
    } catch (error) {
      console.error("Error fetching projects:", error);
    }
  };

  const toggleComplete = async (id, currentStatus) => {
    await fetch(`${TASKS_API_URL}/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ completed: !currentStatus })
    });
    fetchTasks();
  };

  const deleteTask = async (id) => {
    await fetch(`${TASKS_API_URL}/${id}`, { method: 'DELETE' });
    fetchTasks();
  };

  const handleAskQuestion = (e) => {
    e.preventDefault();
    if (!newQuestion.trim()) return;
    
    const newQ = {
      id: Date.now(),
      author: isAnonymous ? 'Anonymous' : 'Admin',
      text: newQuestion,
      replies: 0,
      time: 'Just now'
    };
    
    setQuestions([newQ, ...questions]);
    setNewQuestion('');
  };

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  // Dashboard Statistics
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const pendingTasks = totalTasks - completedTasks;
  const activeProjectsCount = projects.filter(p => p.status !== 'Completed').length;

  // Google 3D Pie Chart Data & Settings
  const pieData = [
    ["Task Status", "Count"],
    ["Completed", completedTasks],
    ["Pending", pendingTasks],
  ];

  const pieOptions = {
    is3D: true,
    backgroundColor: 'transparent',
    colors: ['#10b981', '#f59e0b'], // Green for completed, Orange for pending
    legend: { position: 'bottom', textStyle: { color: '#6b7280', fontSize: 13 } },
    chartArea: { width: '90%', height: '80%' },
  };

  return (
    <div>
      <div className="welcome-section">
        <div className="welcome-text">
          <h1>{getGreeting()}, Admin! 👋</h1>
          <p>Here's what's happening with your tasks and projects today.</p>
        </div>
        <div className="date-picker">
          <Calendar size={16} /> Today, {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
        </div>
      </div>

      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon-wrapper"><Layers size={24} /></div>
          <div className="stat-info"><p>Active Projects</p><h3>{activeProjectsCount}</h3></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper"><CheckCircle size={24} /></div>
          <div className="stat-info"><p>Completed Tasks</p><h3>{completedTasks}</h3></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper"><Clock size={24} /></div>
          <div className="stat-info"><p>Pending Tasks</p><h3>{pendingTasks}</h3></div>
        </div>
        <div className="stat-card">
          <div className="stat-icon-wrapper"><Crown size={24} /></div>
          <div className="stat-info"><p>Total Tasks</p><h3>{totalTasks}</h3></div>
        </div>
      </div>

      <div className="content-grid" style={{ gridTemplateColumns: '1.5fr 1fr', gap: '24px' }}>
        
        {/* LEFT COLUMN: Tasks & Chart */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
          
          {/* RECENT TASKS WIDGET */}
          <div className="card task-list-card">
            <div className="card-header">
              <h3>Recent Tasks</h3>
              <button className="view-all-btn" onClick={() => navigate('/tasks')}>View All Tasks</button>
            </div>
            <table className="task-table">
              <thead>
                <tr><th>Task Name</th><th>Priority</th><th>Due Date</th><th>Status</th><th></th></tr>
              </thead>
              <tbody>
                {tasks.length === 0 && (
                  <tr><td colSpan="5" className="empty-state">No tasks yet. Go to the Tasks menu to create one!</td></tr>
                )}
                {tasks.slice(0, 5).map(task => (
                  <tr key={task.id} className={task.completed ? 'row-completed' : ''}>
                    <td className="task-name-cell">
                      <input 
                        type="checkbox" 
                        checked={task.completed} 
                        onChange={() => toggleComplete(task.id, task.completed)}
                        className="custom-checkbox"
                      />
                      <span>{task.title}</span>
                    </td>
                    <td>
                      <span className={`priority-badge priority-${task.priority}`}>{task.priority}</span>
                    </td>
                    <td className="date-cell">{task.due_date || 'No Date'}</td>
                    <td>
                      <span className={`status-badge ${task.completed ? 'status-active' : 'status-pending'}`}>
                        {task.completed ? 'Completed' : 'Active'}
                      </span>
                    </td>
                    <td>
                      <button className="delete-btn" onClick={() => deleteTask(task.id)}><Trash2 size={16} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* NEW: 3D PIE CHART WIDGET */}
          <div className="card">
            <div className="card-header">
              <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <PieChart size={18} color="#8b5cf6" /> Task Completion Overview
              </h3>
            </div>
            <div style={{ padding: '16px', display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '220px' }}>
              {totalTasks === 0 ? (
                <p style={{ color: '#9ca3af', fontStyle: 'italic' }}>Add tasks to generate your 3D overview!</p>
              ) : (
                <Chart
                  chartType="PieChart"
                  data={pieData}
                  options={pieOptions}
                  width={"100%"}
                  height={"220px"}
                />
              )}
            </div>
          </div>

        </div>

        {/* RIGHT COLUMN: Q&A Board */}
        <div className="card" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
          <div className="card-header" style={{ marginBottom: '16px' }}>
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <MessageSquare size={18} color="#3b82f6" /> Intern Q&A Board
            </h3>
          </div>
          
          <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '12px', paddingBottom: '16px' }}>
            {questions.map(q => (
              <div key={q.id} style={{ padding: '12px', border: '1px solid #f3f4f6', borderRadius: '8px', backgroundColor: '#FAFAFA' }}>
                <p style={{ fontSize: '14px', color: '#374151', lineHeight: '1.4', marginBottom: '8px' }}>"{q.text}"</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '12px', color: '#6b7280' }}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
                    {q.author === 'Anonymous' ? <Ghost size={12} /> : <User size={12} />} {q.author}
                  </span>
                  <span>{q.replies} replies • {q.time}</span>
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={handleAskQuestion} style={{ borderTop: '1px solid #e5e7eb', paddingTop: '16px', marginTop: 'auto' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
              <textarea 
                placeholder="Stuck on a task? Ask the team..." 
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                style={{ width: '100%', padding: '10px', borderRadius: '8px', border: '1px solid #d1d5db', fontSize: '13px', outline: 'none', resize: 'none', minHeight: '60px', fontFamily: 'inherit' }}
              />
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <label style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '13px', color: '#4b5563', cursor: 'pointer' }}>
                  <input type="checkbox" checked={isAnonymous} onChange={() => setIsAnonymous(!isAnonymous)} />
                  Ask Anonymously
                </label>
                <button type="submit" style={{ display: 'flex', alignItems: 'center', gap: '6px', backgroundColor: '#111827', color: '#fff', border: 'none', padding: '6px 14px', borderRadius: '6px', cursor: 'pointer', fontSize: '13px' }}>
                  <Send size={14} /> Post
                </button>
              </div>
            </div>
          </form>
        </div>

      </div>
    </div>
  );
}