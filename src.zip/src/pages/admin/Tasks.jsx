import { useState, useEffect } from 'react';
import { CheckCircle, Clock, Trash2, Plus, SearchX } from 'lucide-react';
import { useSearchParams } from 'react-router-dom';

export default function Tasks() {
  const [tasks, setTasks] = useState([]);
  const [title, setTitle] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [priority, setPriority] = useState('Medium');

  // Search feature hooks
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('q') || '';

  const API_URL = 'http://127.0.0.1:5000/api/tasks';

  useEffect(() => { fetchTasks(); }, []);

  const fetchTasks = async () => {
    try {
      const response = await fetch(API_URL);
      if (!response.ok) throw new Error("Server error");
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error("Error fetching tasks. Is the backend running?", error);
    }
  };

  const addTask = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    
    try {
      const response = await fetch(API_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, due_date: dueDate, priority })
      });
      
      if (!response.ok) {
        alert("Database Error! Your Python server might have crashed.");
        return;
      }

      // Clear the form only if the save was successful
      setTitle(''); setDueDate(''); setPriority('Medium');
      fetchTasks();
    } catch (error) {
      alert("Connection Failed! Please make sure your Python backend (app.py) is currently running in a terminal.");
      console.error(error);
    }
  };

  const toggleComplete = async (id, currentStatus) => {
    try {
      await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ completed: !currentStatus })
      });
      fetchTasks();
    } catch (error) {
      alert("Could not update task. Check backend server.");
    }
  };

  const deleteTask = async (id) => {
    try {
      await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
      fetchTasks();
    } catch (error) {
      alert("Could not delete task. Check backend server.");
    }
  };

  // 1. FILTER TASKS BASED ON SEARCH QUERY
  const filteredTasks = tasks.filter(task => 
    task.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // 2. SPLIT THE ALREADY FILTERED TASKS
  const pendingTasks = filteredTasks.filter(t => !t.completed);
  const completedTasks = filteredTasks.filter(t => t.completed);

  return (
    <div>
      <div className="welcome-section">
        <div className="welcome-text">
          <h1>Task Management 📋</h1>
          <p>Organize, prioritize, and complete your work.</p>
        </div>
      </div>

      <div className="card" style={{ marginBottom: '24px' }}>
        <form onSubmit={addTask} className="add-task-form" style={{ flexDirection: 'row', alignItems: 'flex-end' }}>
          <div className="form-group" style={{ flex: 2 }}>
            <label>Task Title</label>
            <input type="text" placeholder="What needs to be done?" value={title} onChange={(e) => setTitle(e.target.value)} required />
          </div>
          <div className="form-group" style={{ flex: 1 }}>
            <label>Due Date</label>
            <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} required />
          </div>
          <div className="form-group" style={{ flex: 1 }}>
            <label>Priority</label>
            <select value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option value="High">High</option>
              <option value="Medium">Medium</option>
              <option value="Low">Low</option>
            </select>
          </div>
          <button type="submit" className="submit-btn" style={{ marginTop: '0', height: '42px' }}>
            <Plus size={18} /> Add
          </button>
        </form>
      </div>

      {/* Show message if search results are empty */}
      {searchQuery && filteredTasks.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px', color: '#6b7280' }}>
          <SearchX size={48} style={{ margin: '0 auto 16px auto', opacity: 0.5 }} />
          <h3>No tasks found matching "{searchQuery}"</h3>
          <p>Try searching for a different keyword.</p>
        </div>
      )}

      {/* Side-by-Side Task Lists */}
      <div className="content-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
        
        <div className="card">
          <div className="card-header">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <Clock size={18} color="#dd6b20" /> Pending ({pendingTasks.length})
            </h3>
          </div>
          <div className="task-list" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {pendingTasks.map(task => (
              <div key={task.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', border: '1px solid #f3f4f6', borderRadius: '8px', background: '#FAFAFA' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <input type="checkbox" className="custom-checkbox" checked={task.completed} onChange={() => toggleComplete(task.id, task.completed)} />
                  <div>
                    <span style={{ fontWeight: '500', color: '#374151', display: 'block', marginBottom: '4px' }}>{task.title}</span>
                    <div style={{ display: 'flex', gap: '8px' }}>
                      <span className={`priority-badge priority-${task.priority}`}>{task.priority}</span>
                      <span className="date-cell" style={{ fontSize: '12px' }}>{task.due_date}</span>
                    </div>
                  </div>
                </div>
                <button className="delete-btn" onClick={() => deleteTask(task.id)}><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-header">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <CheckCircle size={18} color="#166534" /> Completed ({completedTasks.length})
            </h3>
          </div>
          <div className="task-list" style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
            {completedTasks.map(task => (
              <div key={task.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px', border: '1px solid #f3f4f6', borderRadius: '8px', background: '#FAFAFA', opacity: 0.6 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                  <input type="checkbox" className="custom-checkbox" checked={task.completed} onChange={() => toggleComplete(task.id, task.completed)} />
                  <div>
                    <span style={{ fontWeight: '500', color: '#6b7280', textDecoration: 'line-through', display: 'block' }}>{task.title}</span>
                  </div>
                </div>
                <button className="delete-btn" onClick={() => deleteTask(task.id)}><Trash2 size={16} /></button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}