import { FileText, Download } from 'lucide-react';

export default function Reports() {
  return (
    <div>
      <div className="welcome-section">
        <div className="welcome-text">
          <h1>Analytics & Reports 📈</h1>
          <p>Generate insights based on your task completion rates.</p>
        </div>
        <button className="submit-btn" style={{ marginTop: 0 }}>
          <Download size={18} /> Export PDF
        </button>
      </div>
      
      <div className="card" style={{ textAlign: 'center', padding: '60px 20px' }}>
        <FileText size={48} color="#9ca3af" style={{ marginBottom: '16px' }} />
        <h2 style={{ color: '#374151', marginBottom: '8px' }}>Weekly Performance Report</h2>
        <p style={{ color: '#6b7280' }}>
          You have completed 100% of your high-priority tasks this week! <br/>
          Detailed visual charts will be available in the Pro version.
        </p>
      </div>
    </div>
  );
}