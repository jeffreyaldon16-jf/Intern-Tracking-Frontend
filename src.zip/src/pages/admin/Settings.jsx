import { User, Lock, Bell } from 'lucide-react';

export default function Settings() {
  return (
    <div>
      <div className="welcome-section">
        <div className="welcome-text">
          <h1>Settings ⚙️</h1>
          <p>Manage your account preferences and profile.</p>
        </div>
      </div>

      <div className="content-grid" style={{ gridTemplateColumns: '1fr' }}>
        <div className="card">
          <div className="card-header">
            <h3 style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
              <User size={20} color="#6b7280" /> Profile Information
            </h3>
          </div>
          <form className="add-task-form" style={{ maxWidth: '500px' }}>
            <div className="form-group">
              <label>Full Name</label>
              <input type="text" defaultValue="Admin User" />
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input type="email" defaultValue="admin@interntrack.com" />
            </div>
            <div className="form-group">
              <label>Role</label>
              <input type="text" defaultValue="Super Admin" disabled style={{ backgroundColor: '#f3f4f6' }} />
            </div>
            <button type="button" className="submit-btn" style={{ width: '150px' }}>Save Changes</button>
          </form>
        </div>
      </div>
    </div>
  );
}