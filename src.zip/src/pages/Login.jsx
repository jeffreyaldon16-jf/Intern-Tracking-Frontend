import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.css';
import {
  Mail,
  Lock,
  UserCheck,
  ArrowRight,
  Sun,
  Moon,
  Eye,
  EyeOff,
  CheckCircle
} from 'lucide-react';
import officeImg from '../assets/officeImg.jpg';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);

  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch('http://127.0.0.1:5000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username,
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Invalid username or password');
      }

      // Save logged-in user
      localStorage.setItem('userRole', data.user.role);
      localStorage.setItem(
        'userName',
        data.user.name || data.user.username
      );

      // Redirect
      if (data.user.role === 'admin') {
        navigate('/dashboard');
      } else if (data.user.role === 'intern') {
        navigate('/intern-dashboard');
      } else {
        navigate('/login');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleDarkMode = () => {
    setIsDarkMode(!isDarkMode);

    if (!isDarkMode)
      document.body.classList.add('dark-mode');
    else
      document.body.classList.remove('dark-mode');
  };

  return (
    <div className="login-container">
      <div className="login-card">

        {/* Left Side */}

        <div className="login-left">

          <div className="logo">
            <h2>InternTrack ✨</h2>
          </div>

          <h1>
            Welcome Back <span>👋</span>
          </h1>

          <p>Sign in to continue your internship journey</p>

          {error && (
            <div
              style={{
                color: 'red',
                marginBottom: '15px',
                fontSize: '14px'
              }}
            >
              {error}
            </div>
          )}

          <form onSubmit={handleLogin}>

            <label>Email Address</label>

            <div className="input-box">
              <i className="fa-solid fa-envelope"></i>

              <input
                type="text"
                placeholder="Enter Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
            </div>

            <label>Password</label>

            <div className="input-box">
              <i className="fa-solid fa-lock"></i>

              <input
                type={isPasswordVisible ? 'text' : 'password'}
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />

              <i
                className={`fa-solid ${
                  isPasswordVisible
                    ? 'fa-eye-slash'
                    : 'fa-eye'
                } eye`}
                onClick={() =>
                  setIsPasswordVisible(!isPasswordVisible)
                }
              ></i>

            </div>

            <div className="forgot">
              <a href="/">Forgot Password?</a>
            </div>

            <button
              className="login-btn"
              type="submit"
              disabled={isLoading}
            >
              {isLoading ? 'Signing in...' : 'Sign In →'}
            </button>

            <div className="divider">
              <span>or continue with</span>
            </div>

            <div className="social-buttons">

              <button className="social-btn">
                <i className="fa-brands fa-apple"></i>
                Apple
              </button>

              <button className="social-btn">
                <i className="fa-brands fa-google"></i>
                Google
              </button>

            </div>

            <div className="bottom-text">
              Don't have an account? <a href="/">Create account</a>
            </div>

          </form>

        </div>

        {/* Right Side */}

        <div className="login-right">

          <img src={officeImg} alt="Office" />

          <div className="floating-card top">
            <h4>Task Review With Team</h4>
            <p>09:30am-10:00am</p>
          </div>

          <div className="floating-card bottom">
            <h4>Daily Meeting</h4>
            <p>12:00pm-01:00pm</p>
          </div>

        </div>

      </div>
    </div>
  );
}